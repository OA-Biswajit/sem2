import java.util.*;
public class prog8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner (System.in);
		System.out.print("Enter number of Row and Columns of 2D-Array: ");
		int row=sc.nextInt();
		int col=sc.nextInt();
		int arr [][]=new int [row][col];
		
		for (int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print("Enter elements of 2D-Array: ");
				arr [i][j]=sc.nextInt();

			}

		}
		System.out.println("The elements of 2D array are: ");
		
		for (int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print(arr [i][j]+" ");
			}
			System.out.println();
		}
		
	}

}
