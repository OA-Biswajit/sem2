import java.util.*;
public class prog7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner (System.in);
System.out.println("Enter number of elements of Array: ");
int len=sc.nextInt();
int arr []=new int [len];
for (int i=0;i<len;i++) {
	System.out.println("Enter elements of the array: ");
	arr[i]=sc.nextInt();
//	Minimum element(arr[i]);
			}

	}

}
