import java.util.Scanner;

public class prog9 {

public static double sumMajorDiagonal(double[][] m) {
	int sum=0;
	for (int i=0;i<row;i++) {
		for(int j=0;j<col;j++) {
		
			System.out.print("Enter elements of 2D-Array: ");
			sum+=arr [i][j];
	
		}

	}
	
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner (System.in);
		
		int row=4;
		int col=4;
		double arr [][]=new double [row][col];
		
		for (int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print("Enter elements of 2D-Array: ");
				arr [i][j]=sc.nextInt();
				
			}

		}
//		sumMajorDiagonal(arr [][]);
		
	}
	
}