import java.util.*;
import java.lang.*;
class Student
{
	int Roll,DSA_Mark;
	String Name;
	void getdata(int r,String name,int m)
	{
		Roll=r;
		Name=name;
		DSA_Mark=m;
	}
	void showdata(int d)
	{
		System.out.println("Highest Mark"+d);
	}
	 int highest(int s,int s1,int s2,int s3,int s4)
	{
		int max=Math.max(s, Math.max(s1, Math.max(s2, Math.max(s3, s4))));
		return max;
		
	}
}
public class prog3
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Student s1=new Student();
		s1.getdata(4,"Anisha",100);
		Student s2=new Student();
		s2.getdata(5,"Anish",10);
		Student s3=new Student();
		s3.getdata(6,"nisha",99);
		Student s4=new Student();
		s4.getdata(7,"Isha",70);
		Student s5=new Student();
		s5.getdata(8,"lipsa",75);
		Student s6=new Student();
		int m=s6.highest(s1.DSA_Mark,s2.DSA_Mark,s3.DSA_Mark,s4.DSA_Mark,s5.DSA_Mark);
		System.out.println("Highest Mark"+m);
		sc.close();
	}

}
