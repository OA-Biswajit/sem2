import java.util.*;
public class prog8 {

public static void main(String[] args) 
{
}

}
