
public class prog7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		person p=new person("Biswajit",19);
		Employee e=new Employee("Biswajit",19,93,10.0);
		System.out.println("Name\t\tAge\tEid\tSalary");
		e.empDisplay();
	}

}
class person{
	String name;
	int age;	
	person (String name, int age){
		this.name=name;
	this.age=age;
	}
}
class Employee extends person{
	int Eid;
	double	salary;
	Employee (String name, int age, int Eid, double salary){
		super(name,age);
		this.Eid=Eid;
		this.salary=salary;
	}
	void empDisplay() {
		System.out.println(name+"\t"+age+"\t"+Eid+"\t"+salary);
	}
}