class Complex
{
	int real,image;
	void setdata(int r,int i)
	{
		real=r;
		image=i;
	}
	void display()
	{
		if(image>=0)
		System.out.println(real+" +"+ image+"i");
		else
			System.out.println(real+""+ image+"i");
	}
	public Complex add(Complex a,Complex b )
	{
		Complex sum=new Complex ();
		sum.real=a.real+b.real;
		sum.image=a.image+b.image;
		return sum;
	}
}
public class prog2 
{

	public static void main(String[] args) 
	{
		Complex com=new Complex();
		Complex comp1=new Complex();
		com.setdata(4,-5);
		com.display();
		comp1.setdata(3,4);
		comp1.display();
		Complex comm=new Complex();
		comm=comm.add(com, comp1);
		comm.display();
	}

}
