import java.util.*;
public class prog5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner (System.in);
Deposit D=new Deposit();
D.calc_amt();
D.display();

Deposit D1=new Deposit(3,4,5.6);
D1.calc_amt();
D1.display();

Deposit D2=new Deposit(43,3.0);
D2.calc_amt();
D2.display();

Deposit D3=new Deposit(23,56);
D3.calc_amt();
D3.display();

	}

}
class Deposit{
	
	
	long Principal;
	int Time;
	double 	rate;
	double Total_amt;
	
	Deposit (){
		 
	}
	 Deposit (long Principal, int Time, double rate){
		this.Principal=Principal;
		this.Time=Time;
		this.rate=rate;
	 }
	 Deposit (long Principal, int Time){
		 this.Principal=Principal;
			this.Time=Time;
	 }
	 Deposit (long Principal, double rate){
		 this.Principal=Principal;
		 this.rate=rate;
	 }
	 
	void display(){
System.out.print(Total_amt);
	 }
	void calc_amt() {
		Total_amt = Principal + (Principal*rate*Time)/100;
	}

}