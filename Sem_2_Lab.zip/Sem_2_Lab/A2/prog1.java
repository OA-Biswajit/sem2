import java.util.Scanner;

 class phn
{
	int area_code,exchange,number;
	void input (int a,int e,int n)
	{
		area_code=a;
		exchange=e;
		number=n;
	}
	String display()
	{
		return  "("+area_code+")"+" "+ exchange +"-"+ number;
	}
}
public class prog1
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		phn qq1=new phn();
		qq1 .area_code=212;
		qq1.exchange=767;
		qq1.number=8900;
		
		phn qq2=new phn();
		qq2.input(415, 555, 1212);
		System.out.println("My number is "+qq1.display());
		System.out.println("Your number is"+qq2.display());
				

	}

}
