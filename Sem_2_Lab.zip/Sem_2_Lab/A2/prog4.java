import java.util.*;
public class prog4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		
		product []products =new product[5];
		
		for (int i =0;i<=5;i++) {
		int pid=sc.nextInt();
		int price=sc.nextInt();
		products[i]=new product(pid,price);
		product.tot_price+=price;
		products[i].display();
		}
		System.out.println("Total price of produproduct.tot_pricect is "+product.tot_price);
	}

}
class product{
	int pid;
	int price;
	static int tot_price=0;
	 product(int pid,int price) {
		this.pid=pid;
		this.price=price;
	}
void display ()
	{
		System.out.println("Product id "+pid+"\nprice "+price);
	}
}