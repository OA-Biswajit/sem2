
public class prog6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
	}

}
//abstract class Shape{
////	circle
//	double radius;
////	Square
//	int side;
////	Triangle
//	int base;
//	int heigh;
////	Area
//	double area;
//	
//	
//}	
//Square extends shape{
//	
//	
//	
//	
//	void display() {
//		
//		
//		
//		
//		area=side*sid
//				
//				
//				
//				e;
//		
//		
//		System.out.println("Area of square is "+area);
//	}
//	
//	
//	
//	
//	
//	
//}
//
//
//
//
//Triangle extends  shape{
//	void display() {
//		area=base*heigh;
//		System.out.println("Area of square is "+area);
//	}
//}
//Circle extends  shape{
//	void display() {
//		area=2*Math.PI*radius;
//		System.out.println("Area of square is "+area);
//	}
//}
